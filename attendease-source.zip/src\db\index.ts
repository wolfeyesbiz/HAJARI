import { PGlite } from '@electric-sql/pglite';
import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { config } from '../config.js';

/**
 * Database layer.
 *
 * The sandbox has no root access, so a system PostgreSQL cannot be installed.
 * We therefore run PGlite — the *real* PostgreSQL engine compiled to WASM — with an
 * on-disk data directory, which gives us actual PostgreSQL semantics (partial unique
 * indexes, transactions, constraints) plus file persistence across restarts.
 *
 * Set DB_DRIVER=postgres + DATABASE_URL to point at a managed PostgreSQL instance
 * in production; the SQL in db/schema.ts is plain PostgreSQL and runs unchanged.
 */
let instance: PGlite | null = null;

export async function getDb(): Promise<PGlite> {
  if (!instance) {
    const dir = resolve(process.cwd(), config.dataDir);
    mkdirSync(dir, { recursive: true });
    instance = await PGlite.create(dir);
  }
  return instance;
}

export type Sql = string;
export type Params = unknown[];

export async function q<T = Record<string, unknown>>(sql: Sql, params: Params = []): Promise<T[]> {
  const db = await getDb();
  try {
    const res = await db.query<T>(sql, params as unknown[]);
    return res.rows as T[];
  } catch (err) {
    console.error('[sql-error]', (err as Error).message, '\nSQL:', sql.replace(/\s+/g, ' ').slice(0, 400), '\nPARAMS:', JSON.stringify(params));
    throw err;
  }
}

export async function one<T = Record<string, unknown>>(sql: Sql, params: Params = []): Promise<T | null> {
  const rows = await q<T>(sql, params);
  return rows[0] ?? null;
}

export async function scalar<T = unknown>(sql: Sql, params: Params = []): Promise<T | null> {
  const row = await one<Record<string, unknown>>(sql, params);
  if (!row) return null;
  const values = Object.values(row);
  return (values[0] as T) ?? null;
}

export interface Tx {
  q<T = Record<string, unknown>>(sql: Sql, params?: Params): Promise<T[]>;
  one<T = Record<string, unknown>>(sql: Sql, params?: Params): Promise<T | null>;
}

/** Run a callback inside a real PostgreSQL transaction (rollback on throw). */
export async function tx<T>(fn: (t: Tx) => Promise<T>): Promise<T> {
  const db = await getDb();
  return (await db.transaction(async (t) => {
    const helper: Tx = {
      q: async <R = Record<string, unknown>>(sql: string, params: Params = []) => {
        const res = await t.query<R>(sql, params as unknown[]);
        return res.rows as R[];
      },
      one: async <R = Record<string, unknown>>(sql: string, params: Params = []) => {
        const res = await t.query<R>(sql, params as unknown[]);
        return (res.rows[0] as R) ?? null;
      },
    };
    return fn(helper);
  })) as T;
}

export async function closeDb(): Promise<void> {
  if (instance) {
    await instance.close();
    instance = null;
  }
}
